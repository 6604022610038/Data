const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// ✅ เสิร์ฟไฟล์จากโฟลเดอร์ public
app.use(express.static(path.join(__dirname, "public")));

const clients = {};

wss.on("connection", ws => {
  console.log("🔗 มี client เชื่อมต่อเข้ามา");

  ws.on("message", message => {
    const data = JSON.parse(message);

    if (data.type === "login") {
      ws.username = data.username;
      clients[ws.username] = ws;

      // ส่งสถานะออนไลน์
      broadcastStatus(ws.username, "online");
    }

    if (data.type === "chat") {
      if (clients[data.to]) {
        clients[data.to].send(
          JSON.stringify({ type: "chat", from: ws.username, message: data.message })
        );
      }
    }

    if (data.type === "file") {
      if (clients[data.to]) {
        clients[data.to].send(
          JSON.stringify({
            type: "file",
            from: ws.username,
            filename: data.filename,
            fileData: data.fileData
          })
        );
      }
    }
  });

  ws.on("close", () => {
    if (ws.username) {
      delete clients[ws.username];
      broadcastStatus(ws.username, "offline");
    }
  });
});

function broadcastStatus(user, status) {
  for (let client in clients) {
    clients[client].send(JSON.stringify({ type: "status", user, status }));
  }
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
